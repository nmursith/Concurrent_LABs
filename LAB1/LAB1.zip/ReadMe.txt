Compile the Program Using:
	gcc linked_list_all.c -o <name_prefered> -lpthread -lm
For example:
	gcc linked_list_all.c -o linked_list_all -lpthread -lm

Run The execution file:
	01)     ./linked_list_all.out
		It will ask for parameters from user:
		Eg:
			Enter nInsertion: 
			Enter mOperations: 
			Enter mMemberPercent: 
			Enter mInsertPercent: 
			Enter mDeletePercent: 
			Enter thread count: 
	02)	./linked_list_all.out <no of samples>
			It will give the output of lab results.(parameters are hardcoded)
